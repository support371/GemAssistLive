import { GoogleGenAI, Type, Modality } from "@google/genai";
import type { Article, Domain, DynamicPrompts } from '../types';
import { VIDEO_GENERATION_MESSAGES } from '../constants';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const getArticleSchema = (domain: Domain) => ({
  type: Type.OBJECT,
  properties: {
    title: {
      type: Type.STRING,
      description: `A concise, engaging headline for the ${domain} news article.`,
    },
    summary: {
      type: Type.STRING,
      description: "A detailed summary (2-3 sentences) of the news event or trend.",
    },
    priorityLevel: {
      type: Type.STRING,
      enum: ['Low', 'Medium', 'High', 'Critical'],
      description: "The assessed priority or importance of the information.",
    },
    category: {
      type: Type.STRING,
      description: `A relevant category for the ${domain} topic.`,
    },
    recommendations: {
      type: Type.ARRAY,
      items: {
        type: Type.STRING,
      },
      description: "A list of 2-3 actionable steps or recommendations related to the topic."
    }
  },
  required: ["title", "summary", "priorityLevel", "category", "recommendations"],
});


const promptsSchema = {
    type: Type.OBJECT,
    properties: {
        text: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 5 creative and diverse topics for news articles related to the specified domain."
        },
        image: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 5 creative and visually descriptive prompts for image generation related to the specified domain."
        },
        video: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 5 creative and cinematic prompts for video generation related to the specified domain."
        },
    },
    required: ["text", "image", "video"]
};

export const generateDynamicPrompts = async (domain: Domain): Promise<DynamicPrompts> => {
    try {
        const prompt = `
            Act as a creative content strategist for the ${domain} industry.
            Your task is to generate a diverse and interesting set of prompts for an AI-powered news dashboard.
            Create 5 prompts for text-based articles, 5 prompts for image generation, and 5 prompts for video generation.
            The prompts should cover a range of current and relevant topics within the ${domain} sector.
            Adhere strictly to the provided JSON schema.
        `;
         const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: promptsSchema,
                temperature: 0.9,
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as DynamicPrompts;
    } catch (error) {
        console.error(`Error generating dynamic prompts for ${domain}:`, error);
        throw new Error(`Failed to generate dynamic prompts for the ${domain} domain.`);
    }
};


export const fetchArticles = async (topic: string, domain: Domain): Promise<Article[]> => {
  try {
    const prompt = `
      Act as a senior ${domain} analyst. Your task is to generate a list of 6 recent, realistic, and insightful (but fictional) news articles based on the topic: "${topic}".
      For each article, provide a title, a detailed summary, a priority level, a category, and a list of key recommendations.
      Ensure the content is informative and reflects current trends in ${domain}.
      Adhere strictly to the provided JSON schema for your response.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: { type: Type.ARRAY, items: getArticleSchema(domain) },
        temperature: 0.8,
      },
    });

    const jsonText = response.text.trim();
    const articles = JSON.parse(jsonText) as Article[];
    return articles;
  } catch (error) {
    console.error(`Error fetching ${domain} news:`, error);
    throw new Error(`Failed to retrieve ${domain} insights from Gemini. The AI may be busy or an error occurred.`);
  }
};

export const fetchSingleArticle = async (topic: string, domain: Domain): Promise<Article> => {
  try {
    const prompt = `
      Act as a senior ${domain} analyst. Your task is to generate one recent, realistic, and insightful (but fictional) news article based on the topic: "${topic}".
      Provide a title, a detailed summary, a priority level, a category, and a list of key recommendations.
      Ensure the content is informative and reflects current trends in ${domain}.
      Adhere strictly to the provided JSON schema for your response.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: getArticleSchema(domain),
        temperature: 0.8,
      },
    });

    const jsonText = response.text.trim();
    const article = JSON.parse(jsonText) as Article;
    return article;
  } catch (error) {
    console.error(`Error fetching single ${domain} article:`, error);
    throw new Error(`Failed to retrieve a single ${domain} insight from Gemini.`);
  }
};

export const generateCybersecurityImage = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: `Generate a photorealistic, high-quality image representing this concept: "${prompt}"` }],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return part.inlineData.data;
      }
    }
    throw new Error("No image data found in the response.");
  } catch (error) {
    console.error("Error generating image:", error);
    throw new Error("Failed to generate the image. The AI may be busy or an error occurred.");
  }
};

export const generateCybersecurityVideo = async (
    prompt: string,
    length: 'short' | 'medium' | 'long',
    setLoadingMessage: (message: string) => void
): Promise<string> => {
    // A new instance is created to ensure the latest API key from the dialog is used.
    const videoAI = new GoogleGenAI({ apiKey: process.env.API_KEY });
    let messageIndex = 0;

    try {
        setLoadingMessage(VIDEO_GENERATION_MESSAGES[messageIndex++]);
        
        let lengthDescription = "a short";
        if (length === 'medium') {
            lengthDescription = "a medium-length (approx. 10-15 second)";
        } else if (length === 'long') {
            lengthDescription = "a long-form (approx. 20-25 second)";
        }

        const modifiedPrompt = `Create ${lengthDescription}, cinematic video illustrating this concept: "${prompt}"`;
        
        let operation = await videoAI.models.generateVideos({
            model: 'veo-3.1-fast-generate-preview',
            prompt: modifiedPrompt,
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: '16:9',
            }
        });

        while (!operation.done) {
            setLoadingMessage(VIDEO_GENERATION_MESSAGES[messageIndex % VIDEO_GENERATION_MESSAGES.length]);
            messageIndex++;
            await new Promise(resolve => setTimeout(resolve, 2000));
            operation = await videoAI.operations.getVideosOperation({ operation: operation });
        }

        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (!downloadLink) {
            throw new Error("Video generation completed, but no download link was found.");
        }

        setLoadingMessage("Fetching generated video...");
        const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        
        if (!response.ok) {
            throw new Error(`Failed to download video. Status: ${response.statusText}`);
        }

        const videoBlob = await response.blob();
        return URL.createObjectURL(videoBlob);

    } catch (error) {
        console.error("Error generating video:", error);
        if (error instanceof Error && error.message.includes("Requested entity was not found")) {
             throw new Error("API Key error. Please re-select your API key and try again.");
        }
        throw new Error("Failed to generate the video. Please check your prompt or try again later.");
    }
};