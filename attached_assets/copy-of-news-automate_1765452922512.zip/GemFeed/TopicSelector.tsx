import React from 'react';

interface TopicSelectorProps {
  topics: string[];
  activeTopic: string;
  onSelectTopic: (topic: string) => void;
  disabled: boolean;
}

export const TopicSelector: React.FC<TopicSelectorProps> = ({ topics, activeTopic, onSelectTopic, disabled }) => {
  return (
    <div className="flex flex-wrap justify-center gap-2 md:gap-3 mb-8">
      {topics.map((topic) => (
        <button
          key={topic}
          onClick={() => onSelectTopic(topic)}
          disabled={disabled}
          className={`px-4 py-1.5 text-sm font-medium rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-cyan-500 ${
            activeTopic === topic
              ? 'bg-cyan-500 text-white shadow-md'
              : 'bg-gray-700/50 text-gray-300 hover:bg-gray-700'
          } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {topic}
        </button>
      ))}
    </div>
  );
};