import React from 'react';
import { AutomatedContent } from '../types';
import { ArticleCard } from './ArticleCard';
import { ErrorDisplay } from './ErrorDisplay';

interface AutomatedContentCardProps {
    item: AutomatedContent;
}

const formatTimeAgo = (date: Date): string => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return `${Math.floor(interval)} years ago`;
    interval = seconds / 2592000;
    if (interval > 1) return `${Math.floor(interval)} months ago`;
    interval = seconds / 86400;
    if (interval > 1) return `${Math.floor(interval)} days ago`;
    interval = seconds / 3600;
    if (interval > 1) return `${Math.floor(interval)} hours ago`;
    interval = seconds / 60;
    if (interval > 1) return `${Math.floor(interval)} minutes ago`;
    if (seconds < 10) return "just now";
    return `${Math.floor(seconds)} seconds ago`;
};

export const AutomatedContentCard: React.FC<AutomatedContentCardProps> = ({ item }) => {

    const renderContent = () => {
        switch (item.status) {
            case 'loading':
                return (
                     <div className="flex justify-center items-center py-10">
                        <div className="flex flex-col items-center">
                            <div className="w-10 h-10 border-4 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
                            <p className="mt-4 text-gray-400">Generating new {item.type} content...</p>
                            {item.prompt && <p className="mt-2 text-xs text-gray-500 text-center max-w-md">Topic: "{item.prompt}"</p>}
                        </div>
                    </div>
                );
            case 'error':
                return <ErrorDisplay message={item.error || 'An unknown error occurred.'} />;
            case 'success':
                switch (item.type) {
                    case 'text':
                        return item.data ? <ArticleCard article={item.data} /> : <ErrorDisplay message="Content data is missing."/>;
                    case 'image':
                         return item.data ? (
                          <div className="bg-gray-900/50 rounded-lg overflow-hidden">
                            <img src={item.data} alt={item.prompt || 'Generated Image'} className="w-full h-auto object-cover" />
                            {item.prompt && <p className="p-4 text-sm text-gray-400 italic text-center">"{item.prompt}"</p>}
                          </div>
                        ) : <ErrorDisplay message="Image data is missing."/>;
                    case 'video':
                        return item.data ? (
                          <div className="bg-gray-900/50 rounded-lg overflow-hidden">
                            <video src={item.data} controls autoPlay loop muted className="w-full h-auto" />
                            {item.prompt && <p className="p-4 text-sm text-gray-400 italic text-center">"{item.prompt}"</p>}
                          </div>
                        ) : <ErrorDisplay message="Video data is missing."/>;
                    default:
                        return <ErrorDisplay message="Unknown content type."/>;
                }
            default:
                 return <ErrorDisplay message="Invalid content status."/>;
        }
    };
    
    const typeTitle = item.type.charAt(0).toUpperCase() + item.type.slice(1);
    
    const TextIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
    );
     const ImageIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
    );
    const VideoIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
        </svg>
    );
    const iconsMap = { text: <TextIcon/>, image: <ImageIcon/>, video: <VideoIcon/> };

    const paddingClass = item.type === 'text' && item.status === 'success' ? '' : 'p-6';

    return (
        <div className="bg-gray-800/30 backdrop-blur-md border border-gray-700/50 rounded-xl shadow-lg">
           <div className="p-4 border-b border-gray-700/50 flex justify-between items-center bg-gray-900/20 rounded-t-xl">
                <div className="flex items-center gap-3">
                    {iconsMap[item.type]}
                    <h3 className="text-lg font-bold text-gray-200">Automated {typeTitle} Post</h3>
                </div>
                <span className="text-sm text-gray-500">{formatTimeAgo(item.timestamp)}</span>
           </div>
           <div className={paddingClass}>
                {renderContent()}
           </div>
        </div>
    );
};