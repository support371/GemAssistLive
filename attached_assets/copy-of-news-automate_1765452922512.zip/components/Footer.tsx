import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-transparent mt-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-gray-500 border-t border-gray-700/50">
        <p>&copy; {new Date().getFullYear()} Gem Cyber Monitor. All rights reserved.</p>
        <p className="text-sm mt-2">
            Cybersecurity insights powered by 
            <a href="https://ai.google.dev/" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline ml-1">
                Google Gemini
            </a>.
        </p>
      </div>
    </footer>
  );
};