import React, { useState, useEffect } from 'react';
import { generateCybersecurityVideo } from '../services/geminiService';
import { ErrorDisplay } from './ErrorDisplay';

interface VideoGeneratorProps {
    suggestions: string[];
}

export const VideoGenerator: React.FC<VideoGeneratorProps> = ({ suggestions }) => {
  const [prompt, setPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isApiKeyReady, setIsApiKeyReady] = useState<boolean>(false);
  const [videoLength, setVideoLength] = useState<'short' | 'medium' | 'long'>('short');

  useEffect(() => {
    const checkApiKey = async () => {
        if(window.aistudio) {
            const hasKey = await window.aistudio.hasSelectedApiKey();
            setIsApiKeyReady(hasKey);
        }
    };
    checkApiKey();
  }, []);

  const handleSelectKey = async () => {
    if(window.aistudio) {
        try {
            await window.aistudio.openSelectKey();
            // Assume success to avoid race condition
            setIsApiKeyReady(true);
        } catch(e) {
            console.error("Error opening API key selector", e);
            setError("Could not open the API key selector. Please try again.");
        }
    } else {
        setError("AI Studio context not found. This feature is unavailable.");
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt to generate a video.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setVideoUrl(null);
    
    try {
      const url = await generateCybersecurityVideo(prompt, videoLength, setLoadingMessage);
      setVideoUrl(url);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred while generating the video.';
      setError(errorMessage);
      if (errorMessage.includes("API Key error")) {
        setIsApiKeyReady(false);
      }
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

    const handleSuggestionClick = (suggestion: string) => {
        setPrompt(suggestion);
    };

  if(!isApiKeyReady) {
    return (
        <div className="max-w-2xl mx-auto text-center bg-gray-800/30 backdrop-blur-md border border-gray-700/50 rounded-xl p-8">
            <h2 className="text-2xl font-bold text-cyan-400 mb-4">API Key Required for Video Generation</h2>
            <p className="text-gray-400 mb-6">
                The Veo video generation model requires you to select your own API key. This is a mandatory step before you can generate videos.
                Please ensure you have billing enabled for your project.
            </p>
            <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline mb-6 block">
                Learn more about billing
            </a>
            {error && <div className="my-4"><ErrorDisplay message={error}/></div>}
            <button onClick={handleSelectKey} className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2 px-4 rounded-md transition duration-300">
                Select API Key
            </button>
        </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-gray-800/30 backdrop-blur-md border border-gray-700/50 rounded-xl p-6 md:p-8">
        <h2 className="text-3xl font-bold text-cyan-400 mb-4">AI Video Generator</h2>
        <p className="text-gray-400 mb-6">Bring concepts to life. Describe a scene, and the AI will generate a short video clip.</p>
        
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., A time-lapse video of a skyscraper being built..."
          className="w-full p-3 bg-gray-900/70 border border-gray-600 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition duration-200 text-gray-200 resize-none"
          rows={4}
          disabled={isLoading}
        />

        <div className="my-4 flex items-center gap-4 flex-wrap">
            <p className="text-sm text-gray-500 shrink-0">Desired Length:</p>
            <div className="flex gap-2 flex-wrap">
                {(['short', 'medium', 'long'] as const).map(len => (
                    <button
                        key={len}
                        onClick={() => setVideoLength(len)}
                        disabled={isLoading}
                        className={`text-xs px-3 py-1 rounded-full transition-colors duration-200 disabled:opacity-50 capitalize ${
                            videoLength === len
                                ? 'bg-cyan-500 text-white font-semibold'
                                : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                        }`}
                    >
                        {len}
                    </button>
                ))}
            </div>
        </div>

        <div className="my-4">
            <p className="text-sm text-gray-500 mb-2">Or try a suggestion:</p>
            <div className="flex flex-wrap gap-2">
                 {suggestions.length > 0 ? (
                    suggestions.map(suggestion => (
                        <button key={suggestion} onClick={() => handleSuggestionClick(suggestion)} disabled={isLoading} className="text-xs bg-gray-700 hover:bg-gray-600 text-gray-300 px-3 py-1 rounded-full transition-colors duration-200 disabled:opacity-50">
                            {suggestion}
                        </button>
                    ))
                 ) : (
                    <p className="text-xs text-gray-600">Loading suggestions...</p>
                 )}
            </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={isLoading || !prompt.trim()}
          className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-4 rounded-md transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? 'Generating...' : 'Generate Video'}
        </button>
      </div>

      <div className="mt-8">
        {isLoading && (
            <div className="flex justify-center items-center py-16">
                <div className="flex flex-col items-center">
                    <div className="w-12 h-12 border-4 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
                    <p className="mt-4 text-gray-400 text-center">{loadingMessage || 'Initializing video generation...'}</p>
                    <p className="mt-2 text-xs text-gray-500 text-center">(This can take a few minutes)</p>
                </div>
            </div>
        )}
        {error && <ErrorDisplay message={error} />}
        {videoUrl && (
          <div className="bg-gray-800/30 rounded-lg overflow-hidden border border-gray-700/50">
            <video src={videoUrl} controls autoPlay loop className="w-full h-auto" />
            <p className="p-4 text-sm text-gray-400 italic text-center">"{prompt}"</p>
          </div>
        )}
      </div>
    </div>
  );
};