import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './Header';
import { Footer } from './Footer';
import { ArticleCard } from './ArticleCard';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorDisplay } from './ErrorDisplay';
import { TopicSelector } from '../GemFeed/TopicSelector';
import { fetchArticles, fetchSingleArticle, generateCybersecurityImage, generateCybersecurityVideo, generateDynamicPrompts } from '../services/geminiService';
import { AUTOMATION_INTERVAL, DOMAIN_CONFIG } from '../constants';
import type { Article, AutomatedContent, ContentType, Domain, DynamicPrompts } from '../types';
import { ImageGenerator } from './ImageGenerator';
import { VideoGenerator } from './VideoGenerator';
import { AutomatedFeed } from './AutomatedFeed';
import { LiveConversation } from './LiveConversation';

type View = 'text' | 'image' | 'video' | 'automated' | 'live';

const FileTextIcon = (props: React.SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>;
const ImageIcon = (props: React.SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>;
const VideoIcon = (props: React.SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m22 8-6 4 6 4V8Z"/><rect x="2" y="6" width="14" height="12" rx="2" ry="2"/></svg>;
const RssIcon = (props: React.SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16"/><circle cx="5" cy="19" r="1"/></svg>;
const MicIcon = (props: React.SVGProps<SVGSVGElement>) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>;

const viewConfig: Record<View, { label: string; icon: React.ReactNode }> = {
  text: { label: 'Articles', icon: <FileTextIcon /> },
  image: { label: 'Image Gen', icon: <ImageIcon /> },
  video: { label: 'Video Gen', icon: <VideoIcon /> },
  automated: { label: 'Automated Feed', icon: <RssIcon /> },
  live: { label: 'Live Conversation', icon: <MicIcon /> },
};


const App: React.FC = () => {
  // Domain and Prompt State
  const [domain, setDomain] = useState<Domain>('cybersecurity');
  const [dynamicPrompts, setDynamicPrompts] = useState<DynamicPrompts | null>(null);
  const [isPromptsLoading, setIsPromptsLoading] = useState<boolean>(true);

  // Text view state
  const [articles, setArticles] = useState<Article[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTopic, setActiveTopic] = useState<string>(DOMAIN_CONFIG.cybersecurity.topics[0]);
  
  // App view state
  const [view, setView] = useState<View>('text');

  // Automated Feed state
  const [automatedFeed, setAutomatedFeed] = useState<AutomatedContent[]>([]);
  const [isApiKeyReadyForVideo, setIsApiKeyReadyForVideo] = useState<boolean>(false);
  const [automatedFeedFilters, setAutomatedFeedFilters] = useState<ContentType[]>(['text', 'image', 'video']);
  const [unseenAutomatedContentCount, setUnseenAutomatedContentCount] = useState<number>(0);


  // Fetch dynamic prompts when domain changes
  useEffect(() => {
    const fetchPrompts = async () => {
        setIsPromptsLoading(true);
        try {
            const prompts = await generateDynamicPrompts(domain);
            setDynamicPrompts(prompts);
            // Reset active topic to the first new dynamic topic
            const newActiveTopic = prompts.text[0];
            setActiveTopic(newActiveTopic);
            // Fetch articles for the new topic
            handleFetchNews(newActiveTopic, true);
        } catch (e) {
            setError("Failed to generate dynamic prompts. Please refresh.");
            setDynamicPrompts({ text: [], image: [], video: [] });
        } finally {
            setIsPromptsLoading(false);
        }
    };
    fetchPrompts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [domain]);


  // Check for video API key
  useEffect(() => {
    const checkApiKey = async () => {
        if(window.aistudio) {
            const hasKey = await window.aistudio.hasSelectedApiKey();
            setIsApiKeyReadyForVideo(hasKey);
        }
    };
    checkApiKey();
  }, []);

  const handleSelectKey = async () => {
    if(window.aistudio) {
        try {
            await window.aistudio.openSelectKey();
            setIsApiKeyReadyForVideo(true);
        } catch(e) {
            console.error("Error opening API key selector", e);
        }
    }
  };

  const handleFetchNews = useCallback(async (topic: string, forceRefresh = false) => {
    if (!forceRefresh && topic === activeTopic && articles.length > 0) {
        setIsLoading(false);
        return;
    }
    setIsLoading(true);
    setError(null);
    setActiveTopic(topic);
    try {
      const newsArticles = await fetchArticles(topic, domain);
      setArticles(newsArticles);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      setArticles([]);
    } finally {
      setIsLoading(false);
    }
  }, [domain, activeTopic, articles]);

  useEffect(() => {
    if (view === 'text' && dynamicPrompts) {
      handleFetchNews(activeTopic);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  // Automation logic
  useEffect(() => {
    if (!dynamicPrompts) return;

    const triggerAutomation = async () => {
        if (!dynamicPrompts || dynamicPrompts.text.length === 0) return;

        const now = new Date();
        const textId = `text-${now.getTime()}`;
        const imageId = `image-${now.getTime()}`;
        const videoId = `video-${now.getTime()}`;

        const randomTopic = dynamicPrompts.text[Math.floor(Math.random() * dynamicPrompts.text.length)];
        const randomImagePrompt = dynamicPrompts.image[Math.floor(Math.random() * dynamicPrompts.image.length)];
        const randomVideoPrompt = dynamicPrompts.video[Math.floor(Math.random() * dynamicPrompts.video.length)];
        
        const placeholders: AutomatedContent[] = [
            { id: videoId, type: 'video', status: 'loading', timestamp: now, prompt: randomVideoPrompt },
            { id: imageId, type: 'image', status: 'loading', timestamp: now, prompt: randomImagePrompt },
            { id: textId, type: 'text', status: 'loading', timestamp: now, prompt: randomTopic },
        ];
        setAutomatedFeed(prev => [...placeholders, ...prev]);

        // --- Generate Text ---
        try {
            const article = await fetchSingleArticle(randomTopic, domain);
            setAutomatedFeed(prev => prev.map(item => item.id === textId ? ({ id: item.id, type: 'text', timestamp: item.timestamp, prompt: item.prompt, status: 'success', data: article }) : item));
            if (view !== 'automated') setUnseenAutomatedContentCount(prev => prev + 1);
        } catch (e) {
            setAutomatedFeed(prev => prev.map(item => item.id === textId ? { ...item, status: 'error', error: e instanceof Error ? e.message : 'Unknown error' } : item));
        }

        // --- Generate Image ---
        try {
            const base64Image = await generateCybersecurityImage(randomImagePrompt);
            const imageUrl = `data:image/png;base64,${base64Image}`;
            setAutomatedFeed(prev => prev.map(item => item.id === imageId ? ({ id: item.id, type: 'image', timestamp: item.timestamp, prompt: item.prompt, status: 'success', data: imageUrl }) : item));
            if (view !== 'automated') setUnseenAutomatedContentCount(prev => prev + 1);
        } catch (e) {
            setAutomatedFeed(prev => prev.map(item => item.id === imageId ? { ...item, status: 'error', error: e instanceof Error ? e.message : 'Unknown error' } : item));
        }

        // --- Generate Video ---
        if (isApiKeyReadyForVideo) {
            try {
                const randomVideoLength = (['short', 'medium', 'long'] as const)[Math.floor(Math.random() * 3)];
                const videoUrl = await generateCybersecurityVideo(randomVideoPrompt, randomVideoLength, () => {});
                setAutomatedFeed(prev => prev.map(item => item.id === videoId ? ({ id: item.id, type: 'video', timestamp: item.timestamp, prompt: item.prompt, status: 'success', data: videoUrl }) : item));
                if (view !== 'automated') setUnseenAutomatedContentCount(prev => prev + 1);
            } catch (e) {
                 const errorMessage = e instanceof Error ? e.message : 'Unknown error';
                 if (errorMessage.includes("API Key error")) {
                    setIsApiKeyReadyForVideo(false);
                 }
                setAutomatedFeed(prev => prev.map(item => item.id === videoId ? { ...item, status: 'error', error: errorMessage } : item));
            }
        } else {
             setAutomatedFeed(prev => prev.map(item => item.id === videoId ? { ...item, status: 'error', error: 'API Key not selected. Video generation skipped.' } : item));
        }
    };

    triggerAutomation(); // Trigger once immediately
    const intervalId = setInterval(triggerAutomation, AUTOMATION_INTERVAL);

    return () => {
      clearInterval(intervalId);
    };
  }, [isApiKeyReadyForVideo, dynamicPrompts, domain, view]);

  const handleFilterToggle = (filter: ContentType) => {
    setAutomatedFeedFilters(prev => 
      prev.includes(filter) 
        ? prev.filter(f => f !== filter)
        : [...prev, filter]
    );
  };
  
  const handleViewChange = (newView: View) => {
    if (newView === 'automated') {
      setUnseenAutomatedContentCount(0);
    }
    setView(newView);
  };


  const renderContent = () => {
    if (isPromptsLoading && !['automated', 'live'].includes(view)) return <LoadingSpinner />;

    switch(view) {
      case 'text':
        return (
          <>
            <TopicSelector
              topics={dynamicPrompts?.text || []}
              activeTopic={activeTopic}
              onSelectTopic={(topic) => handleFetchNews(topic)}
              disabled={isLoading || isPromptsLoading}
            />
            <div className="mt-8">
              {isLoading ? (
                <LoadingSpinner />
              ) : error ? (
                <ErrorDisplay message={error} />
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {articles.length > 0 ? (
                    articles.map((article, index) => (
                      <ArticleCard key={index} article={article} />
                    ))
                  ) : (
                    <div className="col-span-full text-center py-16">
                        <p className="text-gray-500 text-xl">No articles found for this topic.</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </>
        );
      case 'image':
        return <ImageGenerator suggestions={dynamicPrompts?.image || []} />;
      case 'video':
        return <VideoGenerator suggestions={dynamicPrompts?.video || []} />;
      case 'automated':
        const filteredFeed = automatedFeed.filter(item => automatedFeedFilters.includes(item.type));
        return <AutomatedFeed
                    feed={filteredFeed}
                    totalFeedCount={automatedFeed.length}
                    isApiKeyReady={isApiKeyReadyForVideo}
                    onSelectKey={handleSelectKey}
                    activeFilters={automatedFeedFilters}
                    onToggleFilter={handleFilterToggle}
                />;
      case 'live':
        const systemInstruction = `You are a helpful and friendly AI assistant specializing in ${domain}. Provide real-time insights and answer questions concisely.`;
        return <LiveConversation systemInstruction={systemInstruction} />;
      default:
        return null;
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-transparent font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-cyan-400 mb-2">{DOMAIN_CONFIG[domain].title}</h1>
          <p className="text-lg text-gray-400 max-w-3xl mx-auto">{DOMAIN_CONFIG[domain].description}</p>
        </div>
        
        <div className="flex justify-center gap-4 mb-8">
          {(['cybersecurity', 'realestate'] as Domain[]).map((d) => (
             <button
              key={d}
              onClick={() => setDomain(d)}
              className={`px-6 py-2 font-semibold rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-cyan-500 capitalize ${
                domain === d
                  ? 'bg-cyan-600 text-white shadow-lg'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              {d}
            </button>
          ))}
        </div>

        <div className="flex justify-center mb-10">
          <div className="p-1.5 bg-gray-800/50 rounded-xl flex flex-wrap justify-center gap-2">
            {(Object.keys(viewConfig) as View[]).map((v) => (
              <button
                key={v}
                onClick={() => handleViewChange(v)}
                className={`flex items-center gap-2 px-4 py-2 font-semibold rounded-lg transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-cyan-500 text-sm md:text-base relative ${
                  view === v
                    ? 'bg-cyan-500 text-white shadow-md'
                    : 'text-gray-300 hover:bg-gray-700/50'
                }`}
              >
                {viewConfig[v].icon}
                <span>{viewConfig[v].label}</span>
                {v === 'automated' && unseenAutomatedContentCount > 0 && (
                  <span className="absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white animate-pulse">
                    {unseenAutomatedContentCount}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {renderContent()}

      </main>
      <Footer />
    </div>
  );
};

export default App;