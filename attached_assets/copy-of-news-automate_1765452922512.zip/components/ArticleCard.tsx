import React from 'react';
import type { Article } from '../types';
import { PriorityLevel } from '../types';

interface ArticleCardProps {
  article: Article;
}

const AlertTriangleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>;
const ChevronUpIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m18 15-6-6-6 6"/></svg>;
const MinusIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/></svg>;
const ChevronDownIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>;

const priorityLevelConfig: Record<PriorityLevel, { styles: string; icon: React.ReactNode }> = {
  [PriorityLevel.Critical]: { styles: 'text-red-400', icon: <AlertTriangleIcon /> },
  [PriorityLevel.High]: { styles: 'text-orange-400', icon: <ChevronUpIcon /> },
  [PriorityLevel.Medium]: { styles: 'text-yellow-400', icon: <MinusIcon /> },
  [PriorityLevel.Low]: { styles: 'text-green-400', icon: <ChevronDownIcon /> },
};

const CheckIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 flex-shrink-0 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
    </svg>
);

export const ArticleCard: React.FC<ArticleCardProps> = ({ article }) => {
  const { styles, icon } = priorityLevelConfig[article.priorityLevel] || priorityLevelConfig[PriorityLevel.Medium];
  
  return (
    <div className="bg-gray-800/20 backdrop-blur-md border border-gray-700/50 rounded-xl overflow-hidden shadow-lg hover:shadow-cyan-500/10 transition-all duration-300 flex flex-col group relative">
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      <div className="p-6 flex-grow flex flex-col z-10">
        <div className="flex justify-between items-center mb-4">
            <span className={`px-3 py-1 text-xs font-bold rounded-full border bg-gray-900/50 border-gray-600`}>
                {article.category}
            </span>
            <span className={`flex items-center gap-2 px-3 py-1 text-xs font-bold rounded-full ${styles}`}>
                {icon}
                {article.priorityLevel}
            </span>
        </div>
        <h3 className="text-xl font-bold text-gray-100 mb-3 flex-grow">{article.title}</h3>
        <p className="text-gray-400 leading-relaxed mb-6 text-sm">{article.summary}</p>
        
        <div>
            <h4 className="text-sm font-semibold text-gray-300 mb-3 border-t border-gray-700/50 pt-4">Key Recommendations</h4>
            <ul className="space-y-3">
                {article.recommendations.map((step, i) => (
                    <li key={i} className="flex items-start text-gray-400 text-sm">
                        <CheckIcon />
                        <span>{step}</span>
                    </li>
                ))}
            </ul>
        </div>
      </div>
    </div>
  );
};