import React from 'react';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex justify-center items-center py-16">
        <div className="flex flex-col items-center">
            <div className="flex items-center justify-center space-x-2">
                <div className="w-4 h-4 rounded-full bg-cyan-400 animate-pulse [animation-delay:-0.3s]"></div>
                <div className="w-4 h-4 rounded-full bg-cyan-400 animate-pulse [animation-delay:-0.15s]"></div>
                <div className="w-4 h-4 rounded-full bg-cyan-400 animate-pulse"></div>
            </div>
            <p className="mt-4 text-gray-400">Analyzing latest threats...</p>
        </div>
    </div>
  );
};