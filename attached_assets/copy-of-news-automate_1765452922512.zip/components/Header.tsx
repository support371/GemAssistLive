import React from 'react';

const ShieldIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 20.944a12.02 12.02 0 009 2.944c4.12 0 7.824-2.12 9.944-5.344a12.02 12.02 0 00-3.326-12.632z" />
    </svg>
);


export const Header: React.FC = () => {
  return (
    <header className="bg-[#0D1117]/80 backdrop-blur-lg border-b border-gray-700/50 sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
              <ShieldIcon />
              <span className="text-xl font-bold text-gray-100 tracking-wider">
                  Gem Cyber Monitor
              </span>
          </div>
        </div>
      </div>
    </header>
  );
};