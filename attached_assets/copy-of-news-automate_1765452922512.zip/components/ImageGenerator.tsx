import React, { useState } from 'react';
import { generateCybersecurityImage } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorDisplay } from './ErrorDisplay';

interface ImageGeneratorProps {
    suggestions: string[];
}

export const ImageGenerator: React.FC<ImageGeneratorProps> = ({ suggestions }) => {
  const [prompt, setPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt to generate an image.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setImageUrl(null);
    try {
      const base64Image = await generateCybersecurityImage(prompt);
      setImageUrl(`data:image/png;base64,${base64Image}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred while generating the image.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setPrompt(suggestion);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-gray-800/30 backdrop-blur-md border border-gray-700/50 rounded-xl p-6 md:p-8">
        <h2 className="text-3xl font-bold text-cyan-400 mb-4">AI Image Generator</h2>
        <p className="text-gray-400 mb-6">Create a visual representation of a concept. Describe a scene, and the AI will generate an image.</p>
        
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., A futuristic city skyline with flying cars..."
          className="w-full p-3 bg-gray-900/70 border border-gray-600 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition duration-200 text-gray-200 resize-none"
          rows={4}
          disabled={isLoading}
        />

        <div className="my-4">
            <p className="text-sm text-gray-500 mb-2">Or try a suggestion:</p>
            <div className="flex flex-wrap gap-2">
                {suggestions.length > 0 ? (
                    suggestions.map(suggestion => (
                        <button key={suggestion} onClick={() => handleSuggestionClick(suggestion)} disabled={isLoading} className="text-xs bg-gray-700 hover:bg-gray-600 text-gray-300 px-3 py-1 rounded-full transition-colors duration-200 disabled:opacity-50">
                            {suggestion}
                        </button>
                    ))
                ) : (
                    <p className="text-xs text-gray-600">Loading suggestions...</p>
                )}
            </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={isLoading || !prompt.trim()}
          className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-4 rounded-md transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? 'Generating...' : 'Generate Image'}
        </button>
      </div>

      <div className="mt-8">
        {isLoading && <LoadingSpinner />}
        {error && <ErrorDisplay message={error} />}
        {imageUrl && (
          <div className="bg-gray-800/30 rounded-lg overflow-hidden border border-gray-700/50">
            <img src={imageUrl} alt={prompt} className="w-full h-auto object-cover" />
            <p className="p-4 text-sm text-gray-400 italic text-center">"{prompt}"</p>
          </div>
        )}
      </div>
    </div>
  );
};