import React, { useState, useRef, useEffect, useCallback } from 'react';
// Fix: Removed `LiveSession` from import as it is not an exported member of the `@google/genai` module.
import { GoogleGenAI, Modality } from '@google/genai';
import { decode, decodeAudioData, createBlob } from '../utils/audioUtils';
import { ErrorDisplay } from './ErrorDisplay';
import { AudioVisualizer } from './AudioVisualizer';
import type { TranscriptEntry } from '../types';

interface LiveConversationProps {
    systemInstruction: string;
}

type Status = 'idle' | 'requesting_permissions' | 'connecting' | 'active' | 'error';

const MicIcon = ({ muted }: { muted: boolean }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        {muted ? (
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3zM1 11h.01M23 11h.01" />
        ) : (
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
        )}
    </svg>
);


export const LiveConversation: React.FC<LiveConversationProps> = ({ systemInstruction }) => {
    const [status, setStatus] = useState<Status>('idle');
    const [error, setError] = useState<string | null>(null);
    const [transcripts, setTranscripts] = useState<TranscriptEntry[]>([]);
    
    // Fix: Changed `LiveSession` to `any` because the type is not exported from the module.
    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const analyserNodeRef = useRef<AnalyserNode | null>(null);
    
    const outputSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    const nextStartTimeRef = useRef<number>(0);

    const stopSession = useCallback(() => {
        if (sessionPromiseRef.current) {
            sessionPromiseRef.current.then(session => session.close());
            sessionPromiseRef.current = null;
        }

        if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach(track => track.stop());
            mediaStreamRef.current = null;
        }

        if (scriptProcessorRef.current) {
            scriptProcessorRef.current.disconnect();
            scriptProcessorRef.current = null;
        }

        if (mediaStreamSourceRef.current) {
            mediaStreamSourceRef.current.disconnect();
            mediaStreamSourceRef.current = null;
        }

        if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
            inputAudioContextRef.current.close();
        }

        if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
            outputAudioContextRef.current.close();
        }

        outputSourcesRef.current.forEach(source => source.stop());
        outputSourcesRef.current.clear();
        
        setStatus('idle');
        setTranscripts([]);
    }, []);
    
    useEffect(() => {
        // Cleanup on component unmount
        return () => {
            stopSession();
        };
    }, [stopSession]);
    
    const handleStartSession = async () => {
        setError(null);
        setStatus('requesting_permissions');
        setTranscripts([]);

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaStreamRef.current = stream;
            
            setStatus('connecting');

            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            // Fix: Cast `window` to `any` to allow for `webkitAudioContext` for broader browser compatibility.
            inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            
            sessionPromiseRef.current = ai.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
                    systemInstruction,
                    outputAudioTranscription: {},
                    inputAudioTranscription: {},
                },
                callbacks: {
                    onopen: () => {
                        const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
                        mediaStreamSourceRef.current = source;
                        
                        const scriptProcessor = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                        scriptProcessorRef.current = scriptProcessor;

                        scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            sessionPromiseRef.current?.then((session) => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };

                        const analyser = inputAudioContextRef.current!.createAnalyser();
                        analyserNodeRef.current = analyser;

                        source.connect(analyser);
                        analyser.connect(scriptProcessor);
                        scriptProcessor.connect(inputAudioContextRef.current!.destination);
                        
                        setStatus('active');
                    },
                    onmessage: async (message) => {
                        if (message.serverContent?.inputTranscription) {
                            // Fix: The 'Transcription' type from the SDK is missing the 'done' property.
                            // We cast to 'any' to access it and provide a default value.
                            const { text, done: isFinal = false } = message.serverContent.inputTranscription as any;
                            setTranscripts(prev => {
                                const last = prev[prev.length - 1];
                                if (last && last.speaker === 'user' && !last.isFinal) {
                                    const updated = { ...last, text, isFinal };
                                    return [...prev.slice(0, -1), updated];
                                }
                                return [...prev, { id: `user-${Date.now()}`, speaker: 'user', text, isFinal }];
                            });
                        }
                        
                        if (message.serverContent?.outputTranscription) {
                            // Fix: The 'Transcription' type from the SDK is missing the 'done' property.
                            // We cast to 'any' to access it and provide a default value.
                            const { text, done: isFinal = false } = message.serverContent.outputTranscription as any;
                            setTranscripts(prev => {
                                const last = prev[prev.length - 1];
                                if (last && last.speaker === 'model' && !last.isFinal) {
                                    const updated = { ...last, text: last.text + text, isFinal };
                                    return [...prev.slice(0, -1), updated];
                                }
                                return [...prev, { id: `model-${Date.now()}`, speaker: 'model', text, isFinal }];
                            });
                        }
                        
                        const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                        if (base64Audio) {
                            const outputCtx = outputAudioContextRef.current!;
                            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
                            const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
                            const source = outputCtx.createBufferSource();
                            source.buffer = audioBuffer;
                            source.connect(outputCtx.destination);
                            source.addEventListener('ended', () => outputSourcesRef.current.delete(source));
                            source.start(nextStartTimeRef.current);
                            nextStartTimeRef.current += audioBuffer.duration;
                            outputSourcesRef.current.add(source);
                        }

                        if (message.serverContent?.interrupted) {
                            outputSourcesRef.current.forEach(source => source.stop());
                            outputSourcesRef.current.clear();
                            nextStartTimeRef.current = 0;
                        }
                    },
                    onerror: (e) => {
                        console.error('Session error:', e);
                        setError('A session error occurred. Please try again.');
                        stopSession();
                    },
                    onclose: () => {
                        // This might be called on purpose, so no error state here
                        console.log('Session closed.');
                    },
                }
            });
            
        } catch (err) {
            console.error(err);
            if (err instanceof DOMException && err.name === 'NotAllowedError') {
                setError('Microphone permission denied. Please allow microphone access in your browser settings.');
            } else {
                setError('Failed to start session. Please ensure your microphone is working and try again.');
            }
            stopSession();
        }
    };
    
    const getStatusText = () => {
        switch(status) {
            case 'idle': return 'Start a conversation with the AI';
            case 'requesting_permissions': return 'Requesting microphone access...';
            case 'connecting': return 'Connecting to the AI...';
            case 'active': return 'Listening...';
            case 'error': return 'An error occurred';
        }
    }

    return (
        <div className="max-w-4xl mx-auto bg-gray-800/30 backdrop-blur-md border border-gray-700/50 rounded-xl p-6 md:p-8">
            <h2 className="text-3xl font-bold text-cyan-400 mb-2">Live AI Conversation</h2>
            <p className="text-gray-400 mb-6">{getStatusText()}</p>

            {error && <div className="mb-4"><ErrorDisplay message={error} /></div>}

            <div className="flex flex-col items-center">
                 {status === 'active' && <AudioVisualizer analyserNode={analyserNodeRef.current} isActive={true} />}

                 <div className="my-6">
                    {status !== 'active' ? (
                        <button
                            onClick={handleStartSession}
                            disabled={status !== 'idle' && status !== 'error'}
                            className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-6 rounded-full transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 text-lg"
                        >
                           <MicIcon muted={false} /> Start Conversation
                        </button>
                    ) : (
                        <button
                            onClick={stopSession}
                            className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-full transition duration-300 flex items-center gap-2 text-lg"
                        >
                            <MicIcon muted={true} /> Stop Conversation
                        </button>
                    )}
                </div>
            </div>

            <div className="mt-6 bg-gray-900/50 p-4 rounded-lg min-h-[200px] max-h-[40vh] overflow-y-auto">
                {transcripts.length === 0 && (
                    <div className="flex items-center justify-center h-full">
                        <p className="text-gray-500">Conversation transcript will appear here...</p>
                    </div>
                )}
                <div className="space-y-4">
                    {transcripts.map(entry => (
                        <div key={entry.id} className={`flex ${entry.speaker === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[80%] p-3 rounded-lg ${entry.speaker === 'user' ? 'bg-cyan-700 text-white' : 'bg-gray-700 text-gray-200'}`}>
                                <p className={`text-sm ${!entry.isFinal ? 'opacity-70 italic' : ''}`}>{entry.text}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

        </div>
    );
};
