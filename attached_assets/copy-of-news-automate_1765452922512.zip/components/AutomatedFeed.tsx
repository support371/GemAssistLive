import React from 'react';
import type { AutomatedContent, ContentType } from '../types';
import { AutomatedContentCard } from './AutomatedContentCard';

interface AutomatedFeedProps {
  feed: AutomatedContent[];
  totalFeedCount: number;
  isApiKeyReady: boolean;
  onSelectKey: () => void;
  activeFilters: ContentType[];
  onToggleFilter: (filter: ContentType) => void;
}

export const AutomatedFeed: React.FC<AutomatedFeedProps> = ({ feed, totalFeedCount, isApiKeyReady, onSelectKey, activeFilters, onToggleFilter }) => {
    
    const needsKeyForVideo = feed.some(item => item.type === 'video' && item.status === 'error' && item.error?.includes('API Key'));
    const allFilters: ContentType[] = ['text', 'image', 'video'];
    
    const renderEmptyState = () => {
        if (totalFeedCount === 0) {
            return (
                <div className="text-center py-16">
                    <p className="text-gray-500 text-xl">Initializing automated feed...</p>
                    <p className="text-gray-600 text-md">New content will be generated shortly.</p>
                </div>
            );
        }
        return (
            <div className="text-center py-16">
                <p className="text-gray-500 text-xl">No content matching the current filters.</p>
                <p className="text-gray-600 text-md">Try adjusting your filter selection.</p>
            </div>
        );
    };

    return (
        <div>
             <div className="flex justify-center items-center gap-3 md:gap-4 mb-8 flex-wrap">
                <p className="text-gray-400 font-semibold shrink-0">Filter by type:</p>
                {allFilters.map(filter => (
                    <button
                        key={filter}
                        onClick={() => onToggleFilter(filter)}
                        className={`px-4 py-1.5 font-semibold rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-cyan-500 capitalize text-sm ${
                            activeFilters.includes(filter)
                            ? 'bg-cyan-500 text-white shadow-lg'
                            : 'bg-gray-700/50 text-gray-300 hover:bg-gray-700'
                        }`}
                        >
                        {filter}
                    </button>
                ))}
             </div>
            
             {needsKeyForVideo && !isApiKeyReady && (
                <div className="max-w-2xl mx-auto text-center bg-gray-800/30 backdrop-blur-md border border-gray-700/50 rounded-xl p-8 mb-8">
                    <h2 className="text-2xl font-bold text-cyan-400 mb-4">API Key Required for Video Generation</h2>
                    <p className="text-gray-400 mb-6">
                       The automated feed tried to generate a video, but an API key is required. Please select your key to enable video generation in the feed.
                    </p>
                    <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline mb-6 block">
                        Learn more about billing
                    </a>
                    <button onClick={onSelectKey} className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2 px-4 rounded-md transition duration-300">
                        Select API Key
                    </button>
                </div>
             )}

            {feed.length === 0 ? renderEmptyState() : (
                <div className="space-y-8">
                    {feed.map(item => (
                        <AutomatedContentCard key={item.id} item={item} />
                    ))}
                </div>
            )}
        </div>
    );
};