import { Domain } from './types';

interface DomainConfig {
    title: string;
    description: string;
    topics: string[];
}

export const DOMAIN_CONFIG: Record<Domain, DomainConfig> = {
    cybersecurity: {
        title: "Cybersecurity Threat Dashboard",
        description: "Your AI-powered source for the latest cyber threats and intelligence.",
        topics: [
            "Latest Phishing Scams",
            "New Malware Strains",
            "AI in Cybersecurity",
            "Zero-Day Vulnerabilities",
            "Cloud Security Threats",
            "IoT Device Security",
        ]
    },
    realestate: {
        title: "Real Estate Market Pulse",
        description: "Your AI-powered source for the latest real estate trends and insights.",
        topics: [
            "Luxury Housing Market Trends",
            "First-Time Home Buyer Tips",
            "Commercial Real Estate Outlook",
            "Sustainable and Green Buildings",
            "Impact of Interest Rates",
            "Top Vacation Rental Markets",
        ]
    }
};

export const VIDEO_GENERATION_MESSAGES: string[] = [
    "Warming up the video synthesis engines...",
    "Analyzing the prompt for cinematic potential...",
    "Rendering the first few frames...",
    "Storyboarding the digital narrative...",
    "Applying visual effects and shaders...",
    "Almost there, finalizing the video stream...",
    "Performing final quality checks...",
];

export const AUTOMATION_INTERVAL = 5 * 60 * 1000; // 5 minutes