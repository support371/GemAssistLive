export enum PriorityLevel {
  Low = 'Low',
  Medium = 'Medium',
  High = 'High',
  Critical = 'Critical',
}

export interface Article {
  title: string;
  summary: string;
  priorityLevel: PriorityLevel;
  category: string;
  recommendations: string[];
}

export type Domain = 'cybersecurity' | 'realestate';

export interface DynamicPrompts {
  text: string[];
  image: string[];
  video: string[];
}


// New types for the automated feed
export type ContentType = 'text' | 'image' | 'video';
export type ContentStatus = 'loading' | 'success' | 'error';

interface BaseAutomatedContent {
  id: string;
  type: ContentType;
  timestamp: Date;
  status: ContentStatus;
  error?: string;
  prompt?: string;
}

export interface AutomatedArticle extends BaseAutomatedContent {
  type: 'text';
  data?: Article;
}

export interface AutomatedImage extends BaseAutomatedContent {
  type: 'image';
  data?: string; // image URL
}

export interface AutomatedVideo extends BaseAutomatedContent {
  type: 'video';
  data?: string; // video URL
}

export type AutomatedContent = AutomatedArticle | AutomatedImage | AutomatedVideo;

// New types for live conversation
export interface TranscriptEntry {
  id: string;
  speaker: 'user' | 'model';
  text: string;
  isFinal: boolean;
}


// Fix: Resolved a TypeScript error by moving the AIStudio interface declaration into the `declare global` block to avoid module-scope conflicts.
declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    aistudio?: AIStudio;
  }
}
